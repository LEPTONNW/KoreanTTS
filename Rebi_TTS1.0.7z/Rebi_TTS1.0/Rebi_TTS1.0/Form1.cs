﻿using NAudio.Dsp;
using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Speech.Synthesis;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Rebi_TTS1._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        public static string words = "";
        private void Start_TTS_btn_Click(object sender, EventArgs e)
        {
            //초기화
            words = "";
            words = richTextBox1.Text.ToString();
            richTextBox1.Text = "";

            Thread Speeach_thr = new Thread(new ThreadStart(Speeach_Btn));
            Speeach_thr.Start();
        }

        public void Speeach_Btn()
        {
            try
            {
                if (String.IsNullOrEmpty(words))
                {
                    MessageBox.Show("먼저 텍스트를 입력해 주세요");
                }

                else
                {
                    SpeechSynthesizer speechSynthesizer = new SpeechSynthesizer();

                    //컴퓨터 사운드 출력구간
                    ////////////////////////////////
                    //자신의 소리를 듣기위한 구간///
                    ////////////////////////////////
                    if(checkBox1.Checked == true)
                    {
                        speechSynthesizer.SetOutputToDefaultAudioDevice();
                        speechSynthesizer.Volume = Convert.ToInt32(trackBar1.Value);
                        speechSynthesizer.SelectVoice("Microsoft Heami Desktop"); // 한국어 지원은 Heami 만 가능, 없어도 됨, 있으면 오류 나는경우가 있는거 같음
                        if (words.Contains("ㅋ"))
                        { words = words.Replace("ㅋ", "크"); }
                        speechSynthesizer.Speak(words);
                    }


                    // VB-Audio Virtual Cable 장치로 출력 설정
                    using (var waveOut = new WaveOutEvent { DeviceNumber = GetVirtualCableDeviceNumber() })
                    {

                        var stream = new MemoryStream();

                        //컴퓨터 사운드 출력구간
                        speechSynthesizer.SetOutputToWaveStream(stream);
                        speechSynthesizer.Volume = Convert.ToInt32(trackBar1.Value);

                        //그래서 목소리를 이퀄라이저로 변조하여 여러개의 목소리로 해결하기로 했다.
                        speechSynthesizer.SelectVoice("Microsoft Heami Desktop"); // 한국어 지원은 Heami 만이 유일함....ㅠㅠ
      
                        if (words.Contains("ㅋ"))
                        { words = words.Replace("ㅋ", "크"); }

                        speechSynthesizer.Speak(words);


                        //출력된 사운드를 가상드라이버로 전달하는 구간
                        stream.Position = 0;
                        var waveReader = new WaveFileReader(stream);
                        waveOut.Init(waveReader);
                        waveOut.Play();

                        //전달이 완료 될 때까지 쓰레드를 잠금
                        while (waveOut.PlaybackState == PlaybackState.Playing)
                        {
                            Thread.Sleep(100);
                        }
                    }
                    
                    
                }
            }

            catch (Exception ea) {
                MessageBox.Show(ea.ToString());
            }
        }

        private int GetVirtualCableDeviceNumber()
        {
            // VB-Audio Virtual Cable의 장치 번호를 찾음
            for (int i = 0; i < WaveOut.DeviceCount; i++)
            {
                var caps = WaveOut.GetCapabilities(i);
                if (caps.ProductName.Contains("CABLE Input"))
                {
                    return i;
                }
            }
            return -1; // 기본 장치
        }



        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label1.Text = "사운드 볼륨 : " + trackBar1.Value.ToString();
        }
    }


    //이퀄라이저 클래스
    public class Equalizer : ISampleProvider
    {
        private readonly ISampleProvider source;
        private readonly BiQuadFilter[] filters;

        public Equalizer(ISampleProvider source, float[] gains)
        {
            this.source = source;

            // 각 필터는 다른 주파수를 처리
            filters = new BiQuadFilter[gains.Length];
            for (int i = 0; i < gains.Length; i++)
            {
                filters[i] = BiQuadFilter.PeakingEQ(44100, 100 * (i + 1), 1.0f, gains[i]);
            }
        }

        public int Read(float[] buffer, int offset, int count)
        {
            int samplesRead = source.Read(buffer, offset, count);

            // 필터를 각 샘플에 적용
            for (int n = 0; n < samplesRead; n++)
            {
                float sample = buffer[offset + n];
                foreach (var filter in filters)
                {
                    sample = filter.Transform(sample);
                }
                buffer[offset + n] = sample;
            }

            return samplesRead;
        }

        public WaveFormat WaveFormat => source.WaveFormat;
    }
}
